//package com.comp272;

/*public class MinSpanTree {

    public class unionFind{
        int[] topers;
        int num_count;



        public unionFind(int n){
            this.topers = new int[n];
            goBackTo();
        }

        public void goBackTo(){
            for(int i = 0; i < topers.length; i++){
                topers[i]  = i;

            }
            num_count = topers.length;
        }

        public int find(int x){
            int toper = topers[x];
            if(toper == x){
                return x;
            }
            else{
                int tip = find(toper);
                topers[x] = tip;
                return tip;
            }
        }

        public boolean union(int i, int j){
            int pointA = find(i);
            int pointB = find(j);

            if(pointA != pointB){
                num_count--;
                topers[pointA] = pointB;
                return true;
            }
            else{
                return false;
            }
        }
    }

    public class Organize {
        int counter = 0;

        public ArrayList<ArrayList<Integer>> findMainEdges(ArrayList<WeightedEdge> graph) {
            ArrayList<WeightedEdge> bo = new ArrayList<>();

            //WeightedEdge x = new WeightedEdge()
            Graph x = new Graph();
            Subset b = new Subset();

            for (WeightedEdge try :bo){

            }
        }
    }
    */

