package com.comp272;
import java.util.*;
public class Edge
{
    int v1;
    int v2;
    int w;

    public Edge (int i, int j) {

        v1=i;
        v2=j;
        //w = k;

    }

   // public static final Comparator<Edge> comp2 = new Comparator<Edge>(){
     //   public int compareToo(Edge one, Edge two){
      //      return Integer.compareToo(one.getWeight(), two.getWeight());
     //   }
   // }//




}